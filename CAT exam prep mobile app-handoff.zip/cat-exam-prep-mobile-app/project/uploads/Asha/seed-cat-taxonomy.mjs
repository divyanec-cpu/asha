/**
 * seed-cat-taxonomy.mjs
 *
 * Seeds the CAT exam config, sections, and the full question-type / set-archetype tree.
 * Run with the SERVICE ROLE key — these are shared reference tables with no write policy.
 *
 *   node scripts/seed-cat-taxonomy.mjs
 *
 * Idempotent: upserts on (exam_id, code).
 *
 * NOTE ON WEIGHTAGES: the `weight_note` strings below are directional figures derived
 * from coaching-site analyses of CAT 2023-2025 papers, not official data. The IIMs
 * publish no syllabus and no topic distribution. Anywhere these surface in the UI they
 * must be labelled as approximate. See CLAUDE.md, "Content-generation discipline".
 */

import { createClient } from '@supabase/supabase-js';

const db = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY,
  { auth: { persistSession: false } }
);

// ─── Exam ────────────────────────────────────────────────────────────────────

const EXAM = { code: 'CAT', name: 'Common Admission Test', adaptive: false, active: true };

const CONFIG = {
  effective_year: 2026,
  total_questions: 68,
  total_time_min: 120,
  mark_correct: 3.0,
  mark_wrong_mcq: -1.0,
  mark_wrong_numeric: 0.0,      // no negative marking on TITA
  section_order_fixed: true,    // VARC → DILR → QA, no switching
  review_edit_limit: null,
  unattempted_penalty: null,
  notes: 'CAT 2026 conducted by IIM Indore, 29 Nov 2026, three slots. Pattern assumed '
       + 'unchanged from 2024/2025 (68Q/204 marks). No pattern change announced in the '
       + '25 Jul 2026 notification. Verify against the information bulletin before the season.',
};

const SECTIONS = [
  { code: 'VARC', name: 'Verbal Ability & Reading Comprehension', ordinal: 1, time_limit_min: 40, question_count: 24 },
  { code: 'DILR', name: 'Data Interpretation & Logical Reasoning', ordinal: 2, time_limit_min: 40, question_count: 22 },
  { code: 'QA',   name: 'Quantitative Ability',                   ordinal: 3, time_limit_min: 40, question_count: 22 },
];

// ─── Taxonomy ────────────────────────────────────────────────────────────────
// Tree shape: { code, name, kind?, description?, children?: [...] }
// kind defaults to 'question_type'. DILR set shapes are 'set_archetype'.

const TAXONOMY = {
  VARC: [
    {
      code: 'VARC.RC', name: 'Reading Comprehension',
      description: '~16 of 24 questions. Log the passage domain AND the question type — '
                 + 'weakness is usually in one or the other, rarely both.',
      children: [
        { code: 'VARC.RC.MAIN',    name: 'Main idea / central theme' },
        { code: 'VARC.RC.INFER',   name: 'Inference', description: 'What follows but is not stated.' },
        { code: 'VARC.RC.FACT',    name: 'Direct / fact-based' },
        { code: 'VARC.RC.TONE',    name: "Author's tone or attitude" },
        { code: 'VARC.RC.VOCAB',   name: 'Vocabulary in context' },
        { code: 'VARC.RC.STRENGTH',name: 'Strengthen / weaken' },
        { code: 'VARC.RC.PURPOSE', name: 'Purpose / structure of passage' },
      ],
    },
    {
      code: 'VARC.PASSAGE', name: 'Passage domain (tag alongside RC questions)',
      description: 'Domain is often the real variable — many aspirants are fine on '
                 + 'business passages and collapse on abstract philosophy.',
      children: [
        { code: 'VARC.PASSAGE.ECON',  name: 'Economics / business' },
        { code: 'VARC.PASSAGE.SCI',   name: 'Science / technology' },
        { code: 'VARC.PASSAGE.PHIL',  name: 'Philosophy / abstract' },
        { code: 'VARC.PASSAGE.SOC',   name: 'Sociology / politics' },
        { code: 'VARC.PASSAGE.HIST',  name: 'History / culture' },
        { code: 'VARC.PASSAGE.ARTS',  name: 'Literature / arts' },
        { code: 'VARC.PASSAGE.PSYCH', name: 'Psychology' },
      ],
    },
    {
      code: 'VARC.VA', name: 'Verbal Ability',
      description: '~8 questions, predominantly TITA — so no negative marking. '
                 + 'Never leave these blank.',
      children: [
        { code: 'VARC.VA.JUMBLE',  name: 'Para jumbles' },
        { code: 'VARC.VA.SUMMARY', name: 'Para summary' },
        { code: 'VARC.VA.ODD',     name: 'Odd sentence out' },
        { code: 'VARC.VA.INSERT',  name: 'Sentence insertion / para completion' },
      ],
    },
  ],

  // DILR carries both set archetypes (the selection engine) and question-level types.
  DILR: [
    {
      code: 'DILR.ARCH', name: 'Set archetypes',
      description: 'Tag every set on the paper — including the ones you never touched. '
                 + 'Skipped sets are what make skip-regret computable.',
      children: [
        { code: 'DILR.ARCH.ARRANGE',   name: 'Arrangements', kind: 'set_archetype',
          description: 'Linear, circular (with direction), matrix/grid, multi-tier. Appears every year.' },
        { code: 'DILR.ARCH.GAMES',     name: 'Games & tournaments', kind: 'set_archetype',
          description: 'Knockout and round-robin, points tables, goal difference, conditional progression. High frequency 2022-2025.' },
        { code: 'DILR.ARCH.BINARY',    name: 'Binary logic / truth-tellers & liars', kind: 'set_archetype' },
        { code: 'DILR.ARCH.VENN',      name: 'Venn diagrams', kind: 'set_archetype',
          description: '2-set and 3-set routinely; 4-set appeared in 2022, 2023 and 2024.' },
        { code: 'DILR.ARCH.SCHEDULE',  name: 'Scheduling / timetabling', kind: 'set_archetype',
          description: 'Increasingly common post-2020.' },
        { code: 'DILR.ARCH.TEAM',      name: 'Team formation / selection', kind: 'set_archetype' },
        { code: 'DILR.ARCH.CASELET',   name: 'Quant-heavy DI caselet', kind: 'set_archetype',
          description: 'Tables with missing values, multi-dimensional caselets. Calculation-intensive.' },
        { code: 'DILR.ARCH.CHART',     name: 'Chart interpretation (bar / line / pie)', kind: 'set_archetype' },
        { code: 'DILR.ARCH.SCATTER',   name: 'Scatter plot / correlation', kind: 'set_archetype',
          description: 'Prominent in CAT 2024. Visual-inference heavy, low calculation.' },
        { code: 'DILR.ARCH.NETWORK',   name: 'Routes & networks', kind: 'set_archetype' },
        { code: 'DILR.ARCH.HYBRID',    name: 'Grid / quant-logic hybrid', kind: 'set_archetype',
          description: 'Growing 2023-2024. Logic scaffold with arithmetic inside.' },
        { code: 'DILR.ARCH.DS',        name: 'Data sufficiency', kind: 'set_archetype' },
      ],
    },
    {
      code: 'DILR.SKILL', name: 'Underlying skill (tag the question, not the set)',
      children: [
        { code: 'DILR.SKILL.DEDUCE',  name: 'Constraint deduction' },
        { code: 'DILR.SKILL.CALC',    name: 'Calculation / approximation' },
        { code: 'DILR.SKILL.READ',    name: 'Data extraction from the exhibit' },
        { code: 'DILR.SKILL.COUNT',   name: 'Counting / enumeration' },
      ],
    },
  ],

  QA: [
    {
      code: 'QA.ARITH', name: 'Arithmetic',
      description: 'The dominant block — roughly 40% of QA in recent papers. '
                 + 'Highest return on revision time.',
      children: [
        { code: 'QA.ARITH.PCT',    name: 'Percentages' },
        { code: 'QA.ARITH.PLD',    name: 'Profit, loss & discount' },
        { code: 'QA.ARITH.RATIO',  name: 'Ratio & proportion' },
        { code: 'QA.ARITH.AVG',    name: 'Averages' },
        { code: 'QA.ARITH.MIX',    name: 'Mixtures & alligations' },
        { code: 'QA.ARITH.TSD',    name: 'Time, speed & distance' },
        { code: 'QA.ARITH.WORK',   name: 'Time & work' },
        { code: 'QA.ARITH.SICI',   name: 'Simple & compound interest' },
      ],
    },
    {
      code: 'QA.ALG', name: 'Algebra',
      description: 'Roughly 27% of QA. Arithmetic + Algebra together are ~60-70% of the section.',
      children: [
        { code: 'QA.ALG.LINEAR',   name: 'Linear equations' },
        { code: 'QA.ALG.QUAD',     name: 'Quadratic equations' },
        { code: 'QA.ALG.INEQ',     name: 'Inequalities & modulus' },
        { code: 'QA.ALG.FUNC',     name: 'Functions' },
        { code: 'QA.ALG.LOG',      name: 'Logarithms' },
        { code: 'QA.ALG.PROG',     name: 'Progressions (AP / GP / HP)' },
        { code: 'QA.ALG.POLY',     name: 'Polynomials' },
        { code: 'QA.ALG.MAXMIN',   name: 'Maxima & minima' },
        { code: 'QA.ALG.IDENT',    name: 'Algebraic identities' },
      ],
    },
    {
      code: 'QA.GEOM', name: 'Geometry & mensuration',
      description: 'Roughly 14% of QA.',
      children: [
        { code: 'QA.GEOM.TRI',     name: 'Triangles' },
        { code: 'QA.GEOM.CIRCLE',  name: 'Circles' },
        { code: 'QA.GEOM.POLY',    name: 'Polygons & quadrilaterals' },
        { code: 'QA.GEOM.COORD',   name: 'Coordinate geometry' },
        { code: 'QA.GEOM.MENS',    name: 'Mensuration (solids)' },
        { code: 'QA.GEOM.TRIG',    name: 'Trigonometry', description: 'Occasional.' },
      ],
    },
    {
      code: 'QA.NUM', name: 'Number systems',
      description: 'Roughly 9% of QA.',
      children: [
        { code: 'QA.NUM.FACT',   name: 'Factors & multiples' },
        { code: 'QA.NUM.REM',    name: 'Remainders' },
        { code: 'QA.NUM.DIV',    name: 'Divisibility' },
        { code: 'QA.NUM.BASE',   name: 'Base systems' },
      ],
    },
    {
      code: 'QA.MODERN', name: 'Modern maths',
      description: 'Roughly 9% of QA.',
      children: [
        { code: 'QA.MODERN.PNC',   name: 'Permutations & combinations' },
        { code: 'QA.MODERN.PROB',  name: 'Probability' },
        { code: 'QA.MODERN.SET',   name: 'Set theory & Venn' },
        { code: 'QA.MODERN.BINOM', name: 'Binomial theorem' },
      ],
    },
  ],
};

// ─── Seed ────────────────────────────────────────────────────────────────────

async function upsertExam() {
  const { data, error } = await db.from('exams')
    .upsert(EXAM, { onConflict: 'code' }).select().single();
  if (error) throw error;
  return data;
}

async function upsertConfig(examId) {
  const { error } = await db.from('exam_configs')
    .upsert({ ...CONFIG, exam_id: examId }, { onConflict: 'exam_id,effective_year' });
  if (error) throw error;
}

async function upsertSections(examId) {
  const rows = SECTIONS.map(s => ({ ...s, exam_id: examId }));
  const { data, error } = await db.from('sections')
    .upsert(rows, { onConflict: 'exam_id,code' }).select();
  if (error) throw error;
  return Object.fromEntries(data.map(s => [s.code, s.id]));
}

async function upsertNode(node, { examId, sectionId, parentId, depth, sortOrder }) {
  const hasChildren = Array.isArray(node.children) && node.children.length > 0;
  const row = {
    exam_id: examId,
    section_id: sectionId,
    parent_id: parentId,
    code: node.code,
    name: node.name,
    kind: node.kind ?? 'question_type',
    depth,
    is_leaf: !hasChildren,
    description: node.description ?? null,
    sort_order: sortOrder,
    active: true,
  };
  const { data, error } = await db.from('question_types')
    .upsert(row, { onConflict: 'exam_id,code' }).select().single();
  if (error) throw error;

  if (hasChildren) {
    for (const [i, child] of node.children.entries()) {
      await upsertNode(child, {
        examId, sectionId, parentId: data.id, depth: depth + 1, sortOrder: i,
      });
    }
  }
  return data;
}

async function main() {
  const exam = await upsertExam();
  console.log(`exam: ${exam.code}`);

  await upsertConfig(exam.id);
  console.log(`config: ${CONFIG.effective_year}`);

  const sectionIds = await upsertSections(exam.id);
  console.log(`sections: ${Object.keys(sectionIds).join(', ')}`);

  let count = 0;
  for (const [sectionCode, roots] of Object.entries(TAXONOMY)) {
    for (const [i, root] of roots.entries()) {
      await upsertNode(root, {
        examId: exam.id,
        sectionId: sectionIds[sectionCode],
        parentId: null,
        depth: 0,
        sortOrder: i,
      });
    }
    const n = roots.reduce((acc, r) => acc + 1 + (r.children?.length ?? 0), 0);
    count += n;
    console.log(`  ${sectionCode}: ${n} nodes`);
  }
  console.log(`\ntaxonomy: ${count} nodes seeded`);
}

main().catch(err => { console.error(err); process.exit(1); });
