# Sextant — Project Brief & Rules

**Read this before writing any code.** This file is the constitution. If a proposed change contradicts anything here, the change is wrong until this file is amended in the same commit, with the reasoning written into `docs/decisions.md`.

## What Sextant is

A mock-test analytics companion for MBA-entrance aspirants. **CAT first.** GMAT and MAT are configuration, not v1.

A sextant does not steer the ship. It tells you where you are. That is the entire product thesis: Sextant does not teach, does not sell mocks, does not replace coaching. The student already has mocks (SimCAT, AIMCAT, iCAT, CL, PYQs) and already has teachers. What they do not have is an honest instrument that reads *their own attempt data* across many mocks and tells them, with stated confidence, where they actually are and what to change next.

Tagline: *"You've taken the mock. Now take your position."*

## Positioning — hard product rules

These are not preferences. Breaking one is a bug.

1. **Sextant does not teach.** No lectures, no concept videos, no original syllabus content. It diagnoses and points at what to revise.
2. **Sextant is not a mock bank.** It never ships a shared library of CAT/GMAT/MAT questions. See "Content and copyright" below — this is the legal moat, not a feature choice.
3. **Sextant never claims more than the data supports.** Every insight carries the sample size it rests on and a confidence label. An insight below the evidence threshold is not shown at all. Overclaiming from n=2 is the fastest way to lose a serious aspirant.
4. **No leaderboards, no ranks, no peer comparison.** Every number a student sees is their own. Percentile is a field the student *reports from their mock platform*, never something Sextant computes or implies.
5. **Sextant never fabricates data.** If timing was estimated rather than measured, every analysis built on it says so. See "The honest-data rule."
6. **Time-to-logged-mock is the product metric.** Any feature that raises it without moving "insight acted upon" gets cut. If logging a mock takes 30 minutes, nobody does it twice.

## Who uses it

Adults. Working professionals and final-year students, 20–30, time-poor, taking 10–30 mocks over a season. **No minors, so no DPDP child-consent architecture** — this is the biggest structural simplification versus Dhruva. Standard adult data-protection obligations still apply: export and delete must work from day one.

## The honest-data rule

Sextant's core asset is trust in its numbers. Three enforcement mechanisms, all mandatory:

- **Timing provenance.** Every mock attempt records `timing_source`: `measured` (captured by Sextant's own timer), `estimated` (student's recall, entered in buckets), or `absent`. Analytics that depend on timing must surface the provenance. Never average measured and estimated timings into one figure without saying so.
- **Evidence thresholds.** No weakness/strength claim about a question type or set archetype is emitted below `MIN_INSTANCES` for that claim class (see `docs/data-model.md`). Below threshold, the UI says "not enough data yet — 3 more sets needed," which is itself useful.
- **Reserved fields stay empty and stay labelled.** If a column exists but nothing populates it yet, it is marked *reserved* in `docs/data-model.md` and no UI reads it. Never render a zero as if it were a measurement.

## Content and copyright — non-negotiable

- **Never ingest, OCR into a shared table, or re-serve any exam's questions.** Indian courts treat exam papers as copyrighted literary works (*ICAI v. Shaunak H. Satya*, (2011) 8 SCC 781). GMAC's terms are explicitly hostile to any reproduction of GMAT items and restrict them to individual exam preparation.
- **The student's uploaded material is private, forever.** Files live in a per-user storage folder, are never read cross-student, are never used to seed shared content, and are never sent to an AI service without the student's explicit per-file action.
- **GMAT content is off-limits even as a private upload** until counsel says otherwise, given GMAC's individual-use licence language. GMAT support in v1 means analytics on the student's own *results*, nothing else.
- **Original practice content only**, if and when micro-quizzes ship: hand-written or agent-drafted-and-hand-verified items over public-domain passages. Never "in the style of" reproductions of real items.
- **Open legal question, flagged deliberately:** whether a student uploading their own purchased mock into a private analytics tool is defensible fair dealing. This needs an IP lawyer's written opinion before any upload feature ships. Until then, build the analytics against *manually entered attempt data only* — which requires no upload at all, and is the MVP anyway.

## Scope boundary — v1

The single biggest failure mode across previous builds was scope creep. This is the fence.

**In v1:**
- CAT only.
- Post-hoc structured review entry: student replays a mock they took elsewhere and logs it.
- The DILR **set-selection engine** — the signature feature. Log all 5 sets including the ones skipped; get a personal pick/skip playbook.
- Core analytics: accuracy and time by question type, the accuracy-vs-time quadrant, marks-per-minute, time-trap flags, confidence calibration, error-cause tagging.
- Cross-mock trend view with explicit confidence labels.
- Export and delete.

**Explicitly deferred — do not build these in v1, however easy they look:**
- In-app timed test mode (v3).
- GMAT and MAT configs (v3 — the schema supports them; the seed data and UI do not ship).
- Micro-quiz / flashcard / Leitner layer (v2 at the earliest).
- OCR of result screenshots (v2).
- Any AI question generation.
- Any AI chat.
- XAT / NMAT / SNAP / CMAT.
- File upload of mock PDFs (blocked on legal opinion regardless).
- Mobile app shell. Web-responsive only until the analytics loop retains users.

**Advance gates.** v1 → v2 requires: a real user has logged **≥5 mocks** and returned to the set-selection view before their next mock. v2 → v3 requires: **>40% of active users log ≥3 mocks** and self-report that an insight changed their set-selection behaviour. No gate, no next stage.

## Stack

Deliberately identical to Dhruva so nothing is re-learned:

- **Frontend:** Next.js (App Router), React, Tailwind, TypeScript.
- **Backend:** Supabase — Postgres + Auth, **RLS on every table, no exceptions.**
- **Auth:** phone + OTP, same MSG91 pattern as Dhruva. Adults only, so no invite/consent flow — a new number goes straight to profile setup.
- **Hosting:** Vercel, auto-deploy from `main`.
- **AI:** none in v1. The app must be fully functional with zero AI calls. If AI arrives in v2 it is server-side only, capped, success-only logging, with a graceful non-AI fallback — the Dhruva pattern.

## Naming and taxonomy discipline

The question-type taxonomy is **data, not code**. It lives in `question_types` as a self-referencing tree, seeded by script, hand-verified before seeding. Adding an exam means adding seed rows. If you find yourself writing an `if (exam === 'CAT')` branch in analytics code, stop — that condition belongs in `exam_configs` or the taxonomy.

Set archetypes (DILR) live in the same tree, distinguished by `kind = 'set_archetype'`, so they roll up through the same aggregation code as question types.

## Content-generation discipline

Any seeded content — taxonomy nodes, archetype definitions, revision-source suggestions — follows Dhruva's rule: drafted, then independently verified against a real source before it is written to a seed script. Weightage figures and archetype frequencies from coaching-site analyses are **directional, not exact**, and must be labelled as such wherever shown.

## Documentation rule

Four docs, updated in the same commit as the change they describe:
- `docs/functional-spec.md` — what it does, in plain language.
- `docs/data-model.md` — every table, every field, what's live and what's reserved.
- `docs/architecture.md` — how it's built.
- `docs/decisions.md` — why a non-obvious choice was made. Append-only, newest first.

If a change would surprise someone reading only the docs, the docs are wrong.
