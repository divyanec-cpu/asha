# Data Model

Status: schema defined, **not yet applied to a live Supabase project**. Nine tables across four migrations. Every table has Row Level Security; shared reference tables are read-only to authenticated users and written only by service-role seed scripts.

The structural difference from Dhruva: there is **no consent/invite graph**. Users are adults, so `users` has no `parent_id`, there is no `child_invites` table, and no DPDP minor-protection constraints apply. Standard adult export/delete obligations remain.

## Shared reference tables

*Same read model as Dhruva's `syllabus_topics`: readable by any authenticated user, written only via service role.*

- **`exams`** — id, code (`CAT`/`GMAT`/`MAT`, unique), name, adaptive (bool), active. Only CAT has `active = true` in v1; GMAT and MAT rows exist so the schema is exercised but no UI exposes them.
- **`exam_configs`** — id, exam_id, effective_year, total_questions, total_time_min, mark_correct, mark_wrong_mcq, mark_wrong_numeric, section_order_fixed, review_edit_limit (GMAT's 3-per-section; null elsewhere), unattempted_penalty (jsonb — XAT's −0.10-beyond-8 rule; null for CAT), notes. Unique on (exam_id, effective_year). **Versioned by year deliberately**: a mid-season pattern change is a data edit, never a code change.
- **`sections`** — id, exam_id, code, name, ordinal, time_limit_min, question_count, has_own_timer, counts_toward_score. Unique on (exam_id, code). `counts_toward_score = false` handles MAT's Indian & Global Environment and XAT's GK without a special case in scoring code.
- **`question_types`** — id, exam_id, section_id, parent_id (self-referencing), code (unique per exam), name, **kind** (`question_type`/`set_archetype`), depth, is_leaf, description, sort_order, active. Unique on (exam_id, code).

  This is the configuration layer. Both question types and DILR set archetypes live in **one tree** so aggregation walks them identically — the only difference is `kind`, which decides whether a row is tagged at question level or set level. Seeded by `scripts/seed-cat-taxonomy.mjs`: **75 CAT nodes** (VARC 21, DILR 18, QA 36), of which **12 are DILR set archetypes**. Only `is_leaf` rows are selectable when logging.

## Per-user tables

*All owner-only RLS. Ownership on the attempt chain is inherited by join, not denormalised — a `user_id` column on `question_attempts` would be a second source of truth waiting to disagree with the first.*

- **`mock_sources`** — id, user_id, provider (`SimCAT`/`AIMCAT`/`iCAT`/`PYQ`/`Other`), title, is_official_pyq, created_at. Metadata only. **There is deliberately no `file_path` column in v1** — uploads are blocked pending an IP opinion (see CLAUDE.md), and the MVP needs no upload because attempt data is entered manually.
- **`mock_attempts`** — id, user_id, exam_id, exam_config_id, source_id (`on delete set null`), taken_on, logged_at, **timing_source** (`measured`/`estimated`/`absent`), **entry_mode** (`post_hoc_log`/`timed_in_app`), total_score, percentile_reported, notes, is_complete. Unique on (user_id, source_id, taken_on).

  `timing_source` is the honest-data rule made structural. v1 writes `estimated` for everything (the student recalls time in buckets during review); `measured` only becomes possible in v3's in-app timer. **No analysis may average across provenances without saying so.** `is_complete` exists because review entry is long enough that it must be resumable — an abandoned half-logged mock is the single likeliest churn event.
- **`section_attempts`** — id, mock_attempt_id, section_id, score, time_used_sec, num_attempted, num_correct, num_incorrect, num_skipped, **quarter_marks** (jsonb `[q1,q2,q3,q4]`), created_at. Unique on (mock_attempt_id, section_id). The quarter split is lifted directly from the GMAT Official Score Report's pacing view — it separates "ran out of time" from "collapsed in the final quarter", which are different problems with different fixes.
- **`set_attempts`** — id, section_attempt_id, archetype_id (→ `question_types` where kind = `set_archetype`), label, num_questions, variable_count (3-var vs 4-var matrix logic), **chosen**, selection_order, time_spent_sec, marks_earned, **solvable_verdict**, created_at.

  **The signature table.** A row exists for *every set on the paper*, including sets the student never touched — those carry `chosen = false`. This is what makes skip-regret computable, and it is the thing no competitor's data model supports. `time_spent_sec` includes time spent scanning a set and then abandoning it, because that time is spent whether or not marks follow. `solvable_verdict` (`cleared` / `attempted_failed` / `skipped_would_have_cleared` / `skipped_correctly` / `abandoned_midway`) is filled during review once the answers are known, and is the raw material of the set-selection playbook.
- **`question_attempts`** — id, section_attempt_id, set_attempt_id (nullable — null outside DILR), question_type_id, question_number, response_format (`mcq`/`tita`), **order_index** (the order the *student* hit it, not paper order), time_spent_sec, status (`attempted`/`skipped`/`revisited`), is_correct (null when skipped), confidence (1–3, declared before checking), **error_cause** (`conceptual`/`misread`/`silly`/`time`/`none`), marks_earned, created_at.

  `response_format` matters more than it looks: CAT applies no negative marking to TITA, so "never leave a TITA blank" is a rule the app can check mechanically. `error_cause` is the four-way root-cause tag that makes recommendations actionable and is the clearest gap in every incumbent product.
- **`insights`** — id, user_id, generated_at, kind (`set_selection`/`time_trap`/`quadrant`/`calibration`/`error_cause`/`pacing`/`skip_regret`), target_type_id, headline, rationale, **supporting_n** (not null, > 0), **confidence_label** (`low`/`medium`/`high`), acted_on, dismissed.

  `supporting_n` and `confidence_label` are `not null` **by design**: it is structurally impossible to store an insight without recording the evidence it rests on. `acted_on` is the primary value metric for the v1 → v2 gate.
- **`revision_queue`** *(RESERVED — defined, never written, no UI reads it)* — id, user_id, question_type_id, box (1–5 → 1-3-7-14-30 days), due_date. Shape settled now so the Leitner layer slots in without a migration, but it is v2 at the earliest per the scope fence.

## Evidence thresholds

Enforced in application code, documented here so the numbers are reviewable rather than buried:

| Insight kind | Minimum observations before it may be shown |
|---|---|
| `set_selection` | 5 sets of that archetype |
| `skip_regret` | 5 skipped sets across ≥3 mocks |
| `time_trap` | 5 attempts of that question type |
| `quadrant` | 8 attempts of that question type |
| `calibration` | 30 confidence-tagged answers |
| `error_cause` | 10 tagged errors in that section |
| `pacing` | 3 mocks |

Below threshold, the UI states what is missing ("3 more Games & Tournaments sets before this is reliable"), which is itself useful information. Confidence labels map to multiples of the threshold: `low` at 1×, `medium` at 2×, `high` at 3×.

## Functions

- **`get_user_id_by_phone(text)`** *(security definer)* — matches an `auth.users` row by digits-only phone. Carried over unchanged from Dhruva, where it fixed a real bug: Supabase normalises stored phone numbers differently from raw input.

## Migration log

- **`0001_core.sql`** — `users` (adults only, no parent graph), owner-only RLS on all four operations, `get_user_id_by_phone`.
- **`0002_taxonomy.sql`** — `exams`, `exam_configs`, `sections`, `question_types`. Read-for-authenticated RLS, no write policies.
- **`0003_attempts.sql`** — `mock_sources`, `mock_attempts`, `section_attempts`, `set_attempts`, `question_attempts`. Owner-only RLS, inherited by join down the chain.
- **`0004_insights.sql`** — `insights` with not-null evidence columns; `revision_queue` reserved.
