# Decisions

Append-only, newest first. Records *why* a non-obvious choice was made, so a future reader doesn't undo it by accident.

## 2026-07-29 — Day zero: schema and taxonomy before any code

**Why docs and migrations first, with no application code.** The stated failure across the previous three builds was scope creep and unclear data models settled too late — features built before the core flow was nailed, then reworked. Dhruva got this right and the earlier builds didn't, and the difference was the doc discipline (`CLAUDE.md` as a constitution, a data-model doc marking live-vs-reserved, an append-only decisions log). That discipline is being carried over wholesale and applied *before* the first line of application code, not after. The schema is the product here — this is an analytics tool, and an analytics tool with the wrong data model is unrecoverable.

**Why an explicit scope fence with numeric advance gates.** "Don't scope-creep" is not an instruction anyone can follow. A written list of things that are explicitly *not* being built, plus a measurable gate before the next stage opens (≥5 mocks logged by a real user; >40% of active users logging ≥3), turns a good intention into a check that can fail. The deferred list deliberately includes things that look easy and tempting — flashcards, AI chat, GMAT support — because those are exactly what pulled the previous builds off course.

## 2026-07-29 — Set archetypes and question types share one taxonomy tree

**Why not two tables.** A DILR set archetype ("Games & Tournaments") and a question type ("Remainders") are tagged at different levels — one on a set, one on a question — which argues for separate tables. They're in one self-referencing tree instead, distinguished by a `kind` column, because every analytic that matters (accuracy rollup, time rollup, marks-per-minute, trend over mocks) is *identical* for both. Two tables would mean two copies of that aggregation code, which would drift. One tree means the set-selection engine and the question-type engine are the same code reading different `kind` values.

**Why the taxonomy is seed data rather than a TypeScript enum.** Adding GMAT or MAT must be a seeding job, not a code change. The moment there is an `if (exam === 'CAT')` branch in analytics code, the multi-exam claim is false. The same logic covers CAT's own drift: the IIMs publish no syllabus, patterns shift year to year, and a new set archetype appearing in CAT 2026 should be a row, not a deploy.

## 2026-07-29 — Every DILR set gets a row, including sets the student never opened

**This is the single most important schema decision in the project.** The obvious model logs what the student attempted. But the whole DILR problem is *selection* — with five sets and time for maybe three, the marks come from picking correctly, not from solving faster. Skipped sets carry the information: which ones were walked past, and (once the answers are known) which of those would have been cleared. A `set_attempts` row with `chosen = false` and a `solvable_verdict` of `skipped_would_have_cleared` is the most valuable row in the database, and a model that only records attempts cannot represent it.

Consequence for the logging UI: the student must be prompted for all five sets, and the two or three they ignored are the ones they'll be least inclined to log. That flow needs to be near-frictionless or the signature feature starves.

**Why `time_spent_sec` on an unchosen set is not always zero.** Scanning a set for ninety seconds and rejecting it costs ninety seconds whether or not marks follow. Recording it is what makes "your scan is too slow" a detectable pattern rather than invisible loss.

## 2026-07-29 — Timing provenance is a column, not a footnote

v1 has no in-app timer, so all per-question timing is the student's recollection entered in buckets. That data is genuinely useful in aggregate and genuinely imprecise, and the temptation will be to display it like measurement. `mock_attempts.timing_source` (`measured` / `estimated` / `absent`) makes the distinction structural rather than a UI convention someone forgets. When the in-app timer ships in v3, historical estimated data stays correctly labelled instead of being silently promoted.

## 2026-07-29 — Evidence thresholds are enforced, and published

`insights.supporting_n` and `insights.confidence_label` are `not null`, so an insight cannot be stored without its evidence base. The thresholds themselves (5 sets for a set-selection claim, 30 answers for calibration, etc.) live in `docs/data-model.md` rather than only in code, because the target user is analytical and sceptical and will reasonably ask "on what basis?".

**The cost is accepted deliberately.** A new user with three mocks sees relatively little. That's worse for early engagement and better for trust, and trust is the entire moat — the competing products all have more content, more mocks and more brand. What they don't have is an instrument that refuses to overclaim.

## 2026-07-29 — No file upload, no shared question bank, no AI in v1

**Copyright is the binding constraint, not a preference.** Indian courts treat exam question papers as copyrighted literary works (*ICAI v. Shaunak H. Satya*, (2011) 8 SCC 781, holding that question papers and model answers "are literary works which are products of human intellect and therefore subject to a copyright"). GMAC's terms restrict GMAT items to individual exam preparation and prohibit derivative works. Coaching sites republishing CAT past papers widely is evidence of non-enforcement, not of legality.

The MVP sidesteps the question entirely: **analytics on manually-entered attempt data require no question content at all.** No upload, no bank, no ingestion, no exposure. Whether a student may upload their own purchased mock into a private analytics tool is a real fair-dealing question that needs a lawyer's written opinion — and it can be answered on its own timeline, in parallel, without blocking the build.

**No AI in v1** for a different reason: none of the v1 analytics need it. Every insight described in the functional spec is arithmetic over the attempt tables. Adding a model would add cost, latency, a failure mode and a caps system for zero additional capability.

## 2026-07-29 — Adults, so no consent architecture

Dhruva's most intricate subsystem — parent accounts, invite codes, per-invite consent records, DPDP minor-protection rules, a parent data window deliberately narrower than surveillance — exists entirely because its users are children. MBA aspirants are adults. That whole graph disappears: no `parent_id`, no `child_invites`, no consent versioning. Export and delete remain, since adult data-protection obligations still apply. This is the largest single simplification versus the reference project, and it's worth stating explicitly so nobody ports the pattern over out of habit.

## 2026-07-29 — Ownership on the attempt chain is inherited by join

`question_attempts` has no `user_id`. RLS reaches the owner through `section_attempts` → `mock_attempts` → `user_id`. Denormalising the user onto every level would be faster to query and would create a second source of truth that can disagree with the first — a class of bug that is silent, corrupting, and discovered late. If profiling later shows the joins matter, the fix is an index or a materialised view, not a denormalised column.
