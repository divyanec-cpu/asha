# Architecture

Status: **schema and seed data only.** No application code yet, no live Supabase project. This document describes the intended build so the first code written has somewhere to go.

## Stack

Deliberately identical to Dhruva, so nothing is re-learned and the known-good patterns carry over:

- **Frontend:** Next.js (App Router), React, Tailwind, TypeScript.
- **Backend / DB / Auth:** Supabase — Postgres + Auth, RLS on every table without exception.
- **Auth:** phone + OTP via MSG91's widget in production, deterministic dev code on localhost (hCaptcha inside the widget refuses to run on localhost — a Dhruva finding, not a guess). Adults only, so no invite or consent flow: a new number goes straight to profile setup.
- **Hosting:** Vercel, auto-deploy from `main`.
- **AI:** none in v1. The app must work end to end with zero model calls.
- **Mobile:** none in v1. Web-responsive only until the analytics loop demonstrably retains users; a Capacitor shell is v3 at the earliest.

## Repository layout (planned)

```
sextant/
  CLAUDE.md                     project brief + rules — read first
  docs/
    architecture.md             this file
    data-model.md               every table, live vs reserved
    decisions.md                why non-obvious choices were made
    functional-spec.md          what it does, in plain language
    changelog.md                dated history (starts at first deploy)
  migrations/
    0001_core.sql               users + phone lookup fn
    0002_taxonomy.sql           exams, exam_configs, sections, question_types
    0003_attempts.sql           mock/section/set/question attempt chain
    0004_insights.sql           insights + reserved revision_queue
  scripts/
    seed-cat-taxonomy.mjs       75 CAT nodes, service-role, idempotent
  src/
    app/
      page.tsx                  session → profile redirect, else auth flow
      log/                      THE CORE LOOP — mock review entry
        [attemptId]/            resumable section-by-section entry
      insights/                 set-selection playbook, quadrant, pacing, calibration
      history/                  cross-mock trend view
      account/                  profile, export, delete
    lib/
      analytics/                pure functions over attempt rows — no DB, no React
      thresholds.ts             evidence thresholds, single source of truth
      supabase/                 browser + server clients
```

## The one architectural rule that matters

**Analytics must be pure functions over attempt rows.** Everything in `lib/analytics/` takes plain arrays in and returns plain objects out — no Supabase client, no React, no side effects. Three reasons:

1. It is testable without a database, which is the only way the maths gets verified.
2. The evidence thresholds are enforced in one place rather than sprinkled through components.
3. When the in-app timer arrives in v3 and timing becomes `measured` rather than `estimated`, the analytics don't change at all — only the provenance label does.

Corollary: **no analytic may branch on exam code.** Marking, timing and structure come from `exam_configs` and `sections`. If a function needs to know it's CAT, the thing it actually needs is a config field that doesn't exist yet.

## Data flow

```
student takes a mock elsewhere
        ↓
  /log  →  mock_attempts (is_complete = false, resumable)
        ↓
  per section  →  section_attempts
        ↓                    ↓
  DILR: set_attempts    VARC/QA: question_attempts
  (all 5 sets, incl.         (type, time bucket,
   skipped, + verdict)        confidence, error cause)
        ↓
  mark complete  →  recompute insights for this user
        ↓
  insights (supporting_n + confidence_label mandatory)
        ↓
  /insights  →  only rows at or above threshold render
```

Insight recomputation runs on attempt completion, over that user's full history — not incrementally. At the scale in question (a few dozen mocks, a few thousand question rows per user) a full recompute is cheap, and it removes an entire class of stale-derived-state bug.

## Security posture

- RLS on every table; no table ships without a policy.
- Shared reference tables (`exams`, `exam_configs`, `sections`, `question_types`) are read-for-authenticated with **no write policies at all** — writes happen only through service-role seed scripts, never from the app.
- Ownership on the attempt chain is inherited by join rather than denormalised (see `decisions.md`).
- Service-role key never reaches the browser; seed scripts run locally or in CI only.
- Export and delete are first-class routes from day one, not a compliance afterthought.

## Next steps

1. Create the Supabase project; apply migrations `0001`–`0004`.
2. Run `seed-cat-taxonomy.mjs`; verify 75 nodes across three sections, 12 archetypes.
3. Scaffold Next.js, wire phone-OTP auth and the profile screen.
4. Build `/log` — the DILR set entry first, since it's the signature feature and the hardest flow to get frictionless.
5. Build `lib/analytics/` with tests before any insight UI exists.
